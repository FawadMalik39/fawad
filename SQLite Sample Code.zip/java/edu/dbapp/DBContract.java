package edu.dbapp;

import android.provider.BaseColumns;

public class DBContract
{
    public static abstract class USER implements BaseColumns
    {
        public static final String TABLE_NAME = "Users";
        public static final String COL_FULL_NAME = "full_name";
        public static final String COL_EMAIL = "email";
    }
}

package edu.dbapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    private DatabaseHelper databaseHelper;

    private EditText txtName, txtEmail;
    private Button btnAddUser, btnShowAll;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper( this );

        txtName = findViewById( R.id.txtName );
        txtEmail = findViewById( R.id.txtEmail );

        btnAddUser = findViewById(R.id.btnAdd );
        btnAddUser.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                addUser();
            }
        });

        btnShowAll = findViewById( R.id.btnShowAll );
        btnShowAll.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity( new Intent(MainActivity.this, ShowUsersActivity.class));
            }
        });
    }

    private void addUser()
    {
        String name = txtName.getText().toString();
        String email = txtEmail.getText().toString();

        if(TextUtils.isEmpty(name) )
        {
            txtName.setError( "Please enter name" );
        }
        else if(TextUtils.isEmpty(email) )
        {
            txtEmail.setError( "Please enter email" );
        }
        else
        {
            SQLiteDatabase db = databaseHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put( DBContract.USER.COL_FULL_NAME, name.trim() );
            values.put( DBContract.USER.COL_EMAIL, email.trim() );

            long id = db.insert( DBContract.USER.TABLE_NAME, null, values );

            if( id > 0 )
            {
                Toast.makeText(this, "Usred added with id: " + id, Toast.LENGTH_SHORT).show();
            }

            db.close();

            txtName.setText( "" );
            txtEmail.setText( "" );
        }
    }
}

package edu.dbapp;

public interface Constants
{
    String KEY_USER_ID ="user_id";
    int RESULT_CODE_EDIT = 1;
    int RESULT_CODE_DELETE = 2;

    int REQUEST_CODE_GET = 3;
}
